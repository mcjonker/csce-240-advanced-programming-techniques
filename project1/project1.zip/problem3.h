// Copyright 2022 Mitchell Jonker
// This file contains the prototypes for the functions.
#ifndef _PROBLEM3_H_
#define _PROBLEM3_H_
int Reverse(int value);
int Reverse(int value, int flips);
int MatchWithReverseDigits(int value, int compare);
#endif  // _PROBLEM3_H_
